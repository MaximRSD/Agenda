<link rel="stylesheet" href="appointments.css">
<link rel="shortcut icon" type="img/png" href="img/favicon.png">
<?php
require_once "functions.php";
?>